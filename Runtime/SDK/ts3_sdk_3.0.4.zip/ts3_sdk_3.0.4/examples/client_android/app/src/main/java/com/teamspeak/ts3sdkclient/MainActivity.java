package com.teamspeak.ts3sdkclient;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

/**
 * TeamSpeak 3 sdk client sample
 *
 * Copyright (c) 2007-2017 TeamSpeak-Systems
 *
 * @author Anna
 * Creation date: 08.02.17
 *
 * Basic Activity to load the ts3 library Example fragment
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        TS3Application app = (TS3Application) getApplication();
        if(savedInstanceState == null){
            Fragment startFragment = new ExampleFragment();

            //Check if the device CPU is supported
            if(!app.isCpuSupported()){
                startFragment = new CpuNotSupportedFragment();
            }

            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment, startFragment)
                    .commit();
        }
    }
}
