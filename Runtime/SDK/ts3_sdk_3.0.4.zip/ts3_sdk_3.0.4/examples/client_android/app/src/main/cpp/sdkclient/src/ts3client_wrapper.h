/*
 * TeamSpeak 3 sdk client sample
 *
 * Copyright (c) 2007-2017 TeamSpeak-Systems
 *
 * @author Alexej
 * Creation date: 09.02.17
 */

#include <jni.h>

#ifndef TEAMSPEAK_SDK_CLIENT_TS3CLIENT_WRAPPER_H_H
#define TEAMSPEAK_SDK_CLIENT_TS3CLIENT_WRAPPER_H_H

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Class:     Java_com_teamspeak_ts3sdkclient_ts3sdk_Native
 * Method:    ts3client_startInit
 * Signature: ()I;
 */
JNIEXPORT jint
JNICALL Java_com_teamspeak_ts3sdkclient_ts3sdk_Native_ts3client_1startInit
        (JNIEnv *, jobject);

/*
 * Class:     Java_com_teamspeak_ts3sdkclient_ts3sdk_Native
 * Method:    ts3client_destroyClientLib
 * Signature: ()I;
 */
JNIEXPORT jint
JNICALL Java_com_teamspeak_ts3sdkclient_ts3sdk_Native_ts3client_1destroyClientLib
        (JNIEnv *, jobject);

/*
 * Class:     Java_com_teamspeak_ts3sdkclient_ts3sdk_Native
 * Method:    ts3client_spawnNewServerConnectionHandler
 * Signature: ()J;
 */
JNIEXPORT jlong
JNICALL Java_com_teamspeak_ts3sdkclient_ts3sdk_Native_ts3client_1spawnNewServerConnectionHandler(JNIEnv * env, jobject);

/*
 * Class:     Java_com_teamspeak_ts3sdkclient_ts3sdk_Native
 * Method:    ts3client_destroyServerConnectionHandler
 * Signature: (J)I;
 */
JNIEXPORT jint
JNICALL Java_com_teamspeak_ts3sdkclient_ts3sdk_Native_ts3client_1destroyServerConnectionHandler(JNIEnv *env, jobject obj, jlong serverConnectionHandlerID);

/*
 * Class:     Java_com_teamspeak_ts3sdkclient_ts3sdk_Native
 * Method:    ts3client_startConnection
 * Signature: (J;Ljava/lang/String;Ljava/lang/String;I;Ljava/lang/String;[Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String)I;
 */
JNIEXPORT jint
JNICALL Java_com_teamspeak_ts3sdkclient_ts3sdk_Native_ts3client_1startConnection(JNIEnv * env, jobject obj, jlong serverConnectionHandlerID,
                                                                           jstring identity, jstring ip, jint port, jstring nickname, jobjectArray channel,
                                                                           jstring defaultChannelPassword, jstring serverPassword);
/*
 * Class:     Java_com_teamspeak_ts3sdkclient_ts3sdk_Native
 * Method:    ts3client_stopConnection
 * Signature: (J;Ljava/lang/String)I;
 */
JNIEXPORT jint
JNICALL Java_com_teamspeak_ts3sdkclient_ts3sdk_Native_ts3client_1stopConnection(JNIEnv *env, jobject obj, jlong serverConnectionHandlerID, jstring msg);


/*
 * Class:     Java_com_teamspeak_ts3sdkclient_ts3sdk_Native
 * Method:    ts3client_createIdentity
 * Signature: ()Ljava/lang/String;
 */
JNIEXPORT jstring
JNICALL Java_com_teamspeak_ts3sdkclient_ts3sdk_Native_ts3client_1createIdentity(JNIEnv * env, jobject);


/*
 * Class:     Java_com_teamspeak_ts3sdkclient_ts3sdk_Native
 * Method:    ts3client_getClientLibVersion
 * Signature: ()Ljava/lang/String;
 */
JNIEXPORT jstring
JNICALL Java_com_teamspeak_ts3sdkclient_ts3sdk_Native_ts3client_1getClientLibVersion(JNIEnv * env, jobject);


/*
 * Class:     Java_com_teamspeak_ts3sdkclient_ts3sdk_Native
 * Method:    ts3client_getClientVariableAsString
 * Signature: (JII)Ljava/lang/String;
 */
JNIEXPORT jstring
JNICALL Java_com_teamspeak_ts3sdkclient_ts3sdk_Native_ts3client_1getClientVariableAsString(JNIEnv *env, jobject obj, jlong serverConnectionHandlerID, jint clientID, jint flag);



/*
 * Class:     Java_com_teamspeak_ts3sdkclient_ts3sdk_Native
 * Method:    ts3client_getChannelVariableAsString
 * Signature: (JJI)Ljava/lang/String;
 */
JNIEXPORT jstring
JNICALL Java_com_teamspeak_ts3sdkclient_ts3sdk_Native_ts3client_1getChannelVariableAsString(JNIEnv *env, jobject obj, jlong serverConnectionHandlerID, jlong channelID, jint flag);

#ifdef __cplusplus
}
#endif

int init();

#endif //TEAMSPEAK_SDK_CLIENT_TS3CLIENT_WRAPPER_H_H
