package com.teamspeak.ts3sdkclient.ts3sdk;
import android.util.Log;

/**
 * TeamSpeak 3 sdk client sample
 *
 * Copyright (c) 2007-2017 TeamSpeak-Systems
 *
 * @author Alexej
 * Creation date: 08.02.17
 *
 * This class loads the ts3sdk library and the generated ts3client-wrapper-lib.
 * From here you can call the library functions defined in ts3client_wrapper.h
 */
public class Native {

    private static final String TAG = Native.class.getSimpleName();

    private static Native instance;
    private static int state;

    public static int getState() {
        return state;
    }

    /**
     * Creates an static instance of the Native interface class and calls ts3client_startInit() to init the ts3library
     * @return a new {@link Native} instance
     */
    public static synchronized Native getInstance() {
        if (Native.instance == null) {
            Native.instance = new Native();
            state = instance.ts3client_startInit();

            /* Query and print client lib version */
            Log.d(TAG,"SDK Library version: " + instance.ts3client_getClientLibVersion());
        }
        return Native.instance;
    }

    /**
     * The native librarys needed to be loaded before they can be used
     */
    public static void loadLibrary() {
        System.loadLibrary("ts3client");
        System.loadLibrary("ts3client-wrapper-lib");
    }

    public native int ts3client_startInit();

    public native int ts3client_destroyClientLib();

    public native long ts3client_spawnNewServerConnectionHandler();

    public native int ts3client_destroyServerConnectionHandler(long serverConnectionHandlerID);

    public native int ts3client_startConnection(long serverConnectionHandlerID, String identity, String ip, int port, String nickname, String[] channel, String defaultChannelPassword, String serverPassword);

    public native int ts3client_stopConnection(long serverConnectionHandlerID, String message);

    public native String ts3client_createIdentity();

    public native String ts3client_getClientLibVersion();

    public native String ts3client_getClientVariableAsString(long serverConnectionHandlerID, int clientID, int flag);

    public native String ts3client_getChannelVariableAsString(long serverConnectionHandlerID, long channelID, int flag);

}
