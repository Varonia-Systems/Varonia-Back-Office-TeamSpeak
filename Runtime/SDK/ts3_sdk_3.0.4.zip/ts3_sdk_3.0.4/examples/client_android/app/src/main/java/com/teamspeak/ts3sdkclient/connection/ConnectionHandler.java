package com.teamspeak.ts3sdkclient.connection;

import android.os.Handler;

import com.teamspeak.ts3sdkclient.ts3sdk.Native;
import com.teamspeak.ts3sdkclient.ts3sdk.states.ConnectStatus;


/**
 * TeamSpeak 3 sdk client sample
 *
 * Copyright (c) 2007-2017 TeamSpeak-Systems
 *
 * @author Anna
 * Creation date: 08.02.17
 *
 * Class that holds all data for one server connection
 */
public class ConnectionHandler {
    private long serverConnectionHandlerId;
    private ConnectionParams mParams;

    @ConnectStatus
    private int currentState = ConnectStatus.STATUS_DISCONNECTED;

    public ConnectionHandler() {
        serverConnectionHandlerId = Native.getInstance().ts3client_spawnNewServerConnectionHandler();
    }

    public int startConnection(ConnectionParams params) {
        mParams = params;

        String ip = params.getServerAddress();
        int port = params.getPort() != 0 ? params.getPort() : 9987;
        String nickname = params.getNickname();
        String defaultChannelPassword = "";
        String serverPassword = "secret";
        String[] defaultChannelArray = new String[]{""};

        /* Connect to server on the given ip address with the given nickname, no default channel, no default channel password and server password "secret" */
        return Native.getInstance().ts3client_startConnection(serverConnectionHandlerId, params.getIdentity(), ip, port, nickname,
                defaultChannelArray, defaultChannelPassword, serverPassword);
    }

    public void disconnect() {
         /* Disconnect from server */
        Native.getInstance().ts3client_stopConnection(serverConnectionHandlerId, "leaving");

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
               /* Destroy server connection handler */
                Native.getInstance().ts3client_destroyServerConnectionHandler(serverConnectionHandlerId);
            }
        }, 200);
    }


    @ConnectStatus
    public int getCurrentState() {
        return currentState;
    }

    public void setCurrentState(int currentState) {
        this.currentState = currentState;
    }

    public ConnectionParams getParams() {
        return mParams;
    }
}
