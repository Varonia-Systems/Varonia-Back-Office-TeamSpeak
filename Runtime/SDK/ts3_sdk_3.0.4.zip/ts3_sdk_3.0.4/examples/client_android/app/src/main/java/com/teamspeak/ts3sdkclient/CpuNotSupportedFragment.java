package com.teamspeak.ts3sdkclient;


import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

/**
 * TeamSpeak 3 sdk client sample
 *
 * Copyright (c) 2007-2017 TeamSpeak-Systems
 *
 * @author Alexej
 * Creation date: 08.02.17
 *
 * Fragment to display a CPU incompatibility message with a button to exit the Application
 */
public class CpuNotSupportedFragment extends Fragment {


	public CpuNotSupportedFragment() {
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
	                         Bundle savedInstanceState) {
		// Inflate the layout for this fragment

		View view = inflater.inflate(R.layout.fragment_cpu_not_supported, container, false);

		Button mConnectButton = (Button) view.findViewById(R.id.button_close_application);
		mConnectButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {

				if(Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP)
				{
					getActivity().finishAndRemoveTask();
				}else{
					getActivity().finish();
				}

			}
		});

		return view;
	}

}
